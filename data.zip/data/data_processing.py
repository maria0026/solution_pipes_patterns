import sys
import pandas as pd
import re
import numpy as np
import math
from matplotlib.path import Path

# Earth radius in meters
R = 6378137.

def dms_string_to_decimal(dms_string):
    # Use regex to extract degrees, minutes, seconds, and direction
    # match = re.match(r"(\d+)\s+(\d+)\'\s+([\d.]+)\"\s+([NSEW])", 
    #                  dms_string.strip())
    
    match = re.match(r"(\d+)°\s+(\d+)'\s+([\d.]+)\"\s+([NSEW])", 
                     dms_string.strip())
    
    
    if not match:
        raise ValueError("Input does not match expected format 'DD MM'" \
                         "SS.SSSS\" D'")

    # Parse the matched groups
    degrees = int(match.group(1))
    minutes = int(match.group(2))
    seconds = float(match.group(3))
    direction = match.group(4)

    # Convert to decimal
    decimal = degrees + minutes / 60 + seconds / 3600
    
    # Apply negative sign for South and West
    if direction in ['S', 'W']:
        decimal *= -1

    return decimal

def per_to_r(per):
    # Perimeter to radius
    return per / 2 / np.pi

def lon_to_x(lon):
    # Longitude to X
    return R * np.cos(ref[1]) * (lon - ref[0])
def lat_to_y(lat):
    # Latitude to Y
    return R * (lat - ref[1])

NAMES = [
'Apulia_Novaglie.csv',
'Apulia_Santa_Sabina.csv',
'Apulia_Santa_Sabina_Area1.csv',
'Apulia_Santa_Sabina_Area2.csv',
'Apulia_Santa_Sabina_Area3.csv',
'Apulia_Santa_Sabina_Area4.csv',
'Apulia_day1.csv',
'Apulia_day1_Area1.csv',
'Apulia_day1_Area2.csv',
'Apulia_day2.csv',
'Apulia_day2_Area1.csv',
'Apulia_day3.csv',
'Apulia_day3_Area1.csv',
'Apulia_day4.csv',
'Australia_Portland_01.csv',
'Australia_Portland_01_Area1.csv',
'Australia_Portland_01_Area2.csv',
'Australia_Portland_01_Area3.csv',
'Australia_Portland_01_Area4.csv',
'Australia_Portland_01_Area5.csv',
'Australia_Portland_01_Area6.csv',
'Australia_Portland_02_Springs.csv',
'Australia_Portland_03_MIS5.csv',
'Australia_Portland_04_West.csv',
'Australia_Portland_05_West.csv',
'Bermuda_Church_Bay.csv',
'Bermuda_Devonshire_Bay_East.csv',
'Bermuda_Devonshire_Bay_East_1.csv',
'Bermuda_Devonshire_Bay_East_2.csv',
'Bermuda_Devonshire_Bay_West.csv',
'Bermuda_Devonshire_Bay_West_1.csv',
'Bermuda_Whalebone_Bay.csv',
'Crete.csv',
'Crete_Area1.csv',
'Sicily.csv',
'Turkey_Region1.csv',
'Turkey_Region1_Area1.csv',
'Turkey_Region1_Area2.csv',
'Turkey_Region2.csv'
]

for name in NAMES:
    
    # loop over all files
    print('Currently processing:', name)
    load_path = f'raw_data/{name}'
    df = pd.read_csv(load_path, usecols=[0, 1, 2])
    
    # convert geo coordinates from string to decimal
    df['X'] = df['X'].apply(dms_string_to_decimal)
    df['Y'] = df['Y'].apply(dms_string_to_decimal)
    
    # convert degrees to radians
    df['X'] = df['X'].apply(math.radians)
    df['Y'] = df['Y'].apply(math.radians)
    
    # change perimeter to radius
    df['PERIMETER'] = df['PERIMETER'].apply(per_to_r)
    df = df.rename(columns={"PERIMETER": "R"})
    
    ref = (df['X'][0], df['Y'][0]) # reference point

    df2 = df.copy()
    
    df['X'] = df['X'].apply(lon_to_x)
    df['Y'] = df['Y'].apply(lat_to_y)

    # Setting geometrical center in (0, 0)
    X = np.sum(df["X"])/len(df["X"])
    Y = np.sum(df["Y"])/len(df["Y"])
    df['X'] = df["X"] - X
    df['Y'] = df["Y"] - Y
    
    # Remove likely false positives
    df = df[df['R'] >= 0.01]
    
    df.to_csv(f"processed/{name[:-4]}.dat", sep="\t", index=False)
    
print('FINISH')